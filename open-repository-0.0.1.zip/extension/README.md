<p align="center">
  <img src="https://github.com/webxmsj/open-repository-button/raw/HEAD/res/icon.png" height="160"/>
</p>

<h1 align="center">VS Code Open in Browser</h1>

<a href="https://marketplace.visualstudio.com/items?itemName=webxmsj.open-repository" target="__blank"><img src="https://img.shields.io/visual-studio-marketplace/v/webxmsj.open-repository.svg?color=eee&amp;label=VS%20Code%20Marketplace&logo=visual-studio-code" alt="Visual Studio Marketplace Version" /></a>

Add a button to go to the GitHub on the status bar.

![](https://raw.githubusercontent.com/webxmsj/images/main/vscode-open-repository.png)

## License

[MIT](https://github.com/webxmsj/open-repository-button/blob/HEAD/LICENSE) License © 2022 [webxmsj](https://github.com/webxmsj)
